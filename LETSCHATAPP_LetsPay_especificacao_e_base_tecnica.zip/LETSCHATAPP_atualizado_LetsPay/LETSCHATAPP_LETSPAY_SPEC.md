# LETSPAY — especificação funcional e técnica

## 1. Objectivo
LetsPay é a carteira digital integrada no LETSCHATAPP e disponível tanto no FREE BASIC como no PREMIUM. Não é uma vantagem exclusiva do plano pago.

## 2. Ecrã inicial
Apresentar:
- Saldo principal em USD.
- Equivalente na moeda local, com indicação de estimativa, código da moeda e data/hora da taxa.
- Acções: **Depósito**, **Levantamento**, **Desbloquear PREMIUM**, **Transferir**.
- Histórico de transacções e estado de cada operação.

A entrada do LetsPay não deve substituir nem reordenar os três separadores principais definidos para o LETSCHATAPP.

## 3. Métodos de pagamento
Disponibilizar como opções pretendidas para depósitos e levantamentos:
- PayPal
- m-Pesa
- e-Mola
- Pix
- Airtm

A aplicação só deve mostrar um método quando o serviço estiver disponível no país do utilizador e a integração comercial/técnica estiver activa e autorizada. A cobertura de m-Pesa e e-Mola é país a país, de acordo com a operação real do serviço e os parceiros/API disponíveis.

## 4. Transferências entre utilizadores
- Solicitar permissão Android para aceder aos contactos.
- Normalizar números para formato internacional E.164.
- Fazer correspondência no backend com utilizadores registados.
- Mostrar apenas contactos correspondentes a contas elegíveis.
- Permitir convite para contactos sem conta, sem criar uma transferência pendente de dinheiro para não-utilizador.
- Confirmar destinatário, montante, moeda e taxas antes de enviar.
- Exigir autenticação reforçada/PIN e confirmação do servidor.

Não expor a lista completa de números de telefone a outros utilizadores.

## 5. Conta LetsPay e PIN
- Criar automaticamente um perfil LetsPay após o registo LETSCHATAPP com número de telefone.
- A criação do perfil não significa que a carteira esteja autorizada a receber/manter dinheiro; operações ficam condicionadas a país, KYC e aprovação do parceiro.
- PIN de exactamente quatro dígitos.
- Rejeitar PIN iniciado por 1 ou 2, 0000, 1234, quatro dígitos iguais, sequências óbvias e padrões comuns.
- Nunca guardar nem transmitir PIN em texto simples; usar derivação/hash apropriado no backend, salt único e protecção contra força bruta.
- Limitar tentativas, aplicar bloqueio progressivo e recuperação de acesso verificada.

## 6. Regra dos 10 minutos
Depois de uma transacção financeira concluída com sucesso, aplicar um intervalo de 10 minutos antes da próxima operação financeira iniciada pelo mesmo utilizador.

Escopo recomendado: depósitos, levantamentos, transferências e pagamento de subscrição Premium.
- A contagem começa no timestamp de conclusão confirmado pelo backend.
- Operações falhadas/canceladas não iniciam o intervalo.
- O backend é a autoridade; o temporizador local serve apenas para mostrar o tempo restante.
- O backend deve recusar operações durante o intervalo, mesmo se o cliente for manipulado.

## 7. Saldo, limite e câmbio
- Limite de saldo pretendido: USD 1.000.000 por utilizador, sujeito a KYC, limites de risco, parceiro e lei local.
- Armazenar valores como inteiros em cêntimos.
- Mostrar USD como saldo contabilístico principal.
- Mostrar também valor aproximado na moeda local, usando taxa obtida de fonte autorizada e indicando taxa/data/hora.
- Não alterar o saldo USD apenas porque a taxa de câmbio mudou.
- Na conversão efectiva, apresentar a taxa, spread, taxas e montante final antes da confirmação.

## 8. PREMIUM e conta do desenvolvedor
- Preço actualmente definido: 5 MZN por mês.
- O pagamento deve ser confirmado pelo fornecedor antes de activar o Premium.
- Após confirmação, lançar o valor líquido e as taxas de forma auditável e creditar a parte devida na conta LetsPay do desenvolvedor.
- Tratar estornos, reembolsos, chargebacks e falhas de confirmação.
- A ACF continua gratuita nos dois planos.

## 9. Modelo de dados recomendado
- `wallets/{userId}`: moeda base, saldo contabilístico, estado KYC, limites e timestamps.
- `wallets/{userId}/transactions/{transactionId}`: tipo, montante em unidades mínimas, moeda, estado, fornecedor, referência externa, idempotency key, timestamps e metadados não sensíveis.
- `paymentIntents/{intentId}`: intenção e estado do pagamento.
- `fxRates/{pair}`: taxa, fonte, validade e timestamp.
- `users/{userId}`: referência ao perfil LetsPay; não guardar PIN em texto simples.

Todas as alterações de saldo devem ocorrer no backend através de operações atómicas e ledger de dupla entrada. O cliente só lê os dados autorizados.

## 10. Requisitos legais e operacionais
Antes de operar com dinheiro real:
- Identificar entidade legal responsável e países de operação.
- Obter licenças ou contratar instituições/parceiros autorizados para serviços de pagamento/custódia.
- Implementar KYC/AML, sanções, monitorização antifraude e suporte a disputas.
- Confirmar termos, APIs, taxas, moedas, limites e disponibilidade geográfica de cada fornecedor.
- Verificar as regras de cobrança de bens/serviços digitais da Google Play.
- Publicar termos, privacidade, política de reembolso e processo de reclamações.

## 11. Critérios de aceitação
- LetsPay aparece no FREE BASIC e PREMIUM.
- Destinatário de transferência é seleccionado dos contactos autorizados e validado contra contas LETSCHATAPP.
- Segunda operação é recusada pelo backend durante 10 minutos após uma operação concluída.
- Métodos de pagamento são filtrados por país e integração activa.
- Saldo mostra USD e equivalente local estimado.
- Nenhum cliente consegue alterar saldo ou marcar uma transacção como concluída.
- PIN fraco é rejeitado e nunca é guardado em texto simples.
- O pagamento Premium só activa após confirmação externa e o crédito ao desenvolvedor fica auditável.
