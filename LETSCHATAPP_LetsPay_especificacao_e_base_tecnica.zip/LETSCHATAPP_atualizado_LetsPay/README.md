# LETSCHATAPP — documentação actualizada

**Aplicação Android de mensagens, Bíblia Sagrada, ficheiros e carteira digital LetsPay.**

Este pacote preserva a base de código recebida (v0.6.0) e acrescenta a especificação consolidada do LetsPay e utilitários de validação. Não representa ainda uma aplicação financeira pronta para movimentar dinheiro.

## Decisões confirmadas do projecto

### Planos
- **FREE BASIC:** 0 MZN/mês.
- **PREMIUM:** 5 MZN/mês (nome de apresentação escolhido para substituir PRO).
- A Bíblia Sagrada ACF permanece desbloqueada em todos os planos.
- **LetsPay está disponível no FREE BASIC e no PREMIUM**, sem exigir subscrição Premium.

### Menu principal
Manter os três separadores, nesta ordem:
1. LETSCHAT GERAL
2. BÍBLIA SAGRADA - ACF
3. FILES SALVOS

A apresentação visual deve respeitar as escolhas de design confirmadas pelo proprietário. A entrada do LetsPay deve ser acrescentada sem alterar a ordem dos três separadores principais.

## LetsPay — requisitos consolidados

1. Depósitos: PayPal, m-Pesa, e-Mola, Pix e Airtm.
2. Levantamentos: PayPal, m-Pesa, e-Mola, Pix e Airtm.
3. Desbloqueio do PREMIUM dentro do LetsPay.
4. Transferências entre utilizadores, seleccionando o destinatário na lista telefónica do Android, com autorização do utilizador e correspondência com uma conta LETSCHATAPP.
5. Carteira com limite de saldo pretendido de **US$ 1.000.000 por utilizador**.
6. Criação automática do perfil LetsPay após o registo no LETSCHATAPP por número de telefone. Antes de movimentar dinheiro, cumprir verificações de identidade e requisitos legais aplicáveis.
7. PIN de quatro dígitos: rejeitar 0000, 1234, PIN iniciado por 1 ou 2, dígitos repetidos, sequências e padrões triviais. O PIN nunca deve ser guardado em texto simples.
8. Após cada transacção concluída com sucesso, aguardar **10 minutos** antes de iniciar outra transacção financeira. O servidor deve impor esta regra; o bloqueio no ecrã é apenas informativo.
9. m-Pesa e e-Mola devem ser apresentados nos países em que cada serviço opere e onde exista integração/parceiro autorizado. Não prometer cobertura universal antes de confirmar os países e APIs.
10. Mostrar saldo principal em USD e também o equivalente na moeda local. O equivalente local é uma estimativa com taxa e hora da última actualização; o valor final depende da taxa aplicada pelo fornecedor na conversão.
11. O pagamento do PREMIUM deve ser creditado na conta LetsPay do desenvolvedor após confirmação do fornecedor, com registo de taxas, reembolsos e estornos.

## Segurança e arquitectura financeira

- Valores monetários devem ser guardados em unidades inteiras (por exemplo, cêntimos), nunca em ponto flutuante.
- O saldo e o livro-razão (ledger) são controlados pelo backend.
- O telemóvel não pode escrever directamente saldos nem criar transacções confirmadas.
- Cada operação precisa de identificador único/idempotência, validação do fornecedor e registo imutável.
- Aplicar o intervalo de 10 minutos no servidor, por utilizador, após uma operação concluída.
- Proteger PIN com hash seguro no backend, limitação de tentativas, bloqueio progressivo e recuperação verificada.
- Implementar KYC/AML, prevenção de fraude, limites por país e licenças/parceiros financeiros antes de custodiar ou transferir fundos.
- Confirmar regras dos fornecedores e da Google Play para cobrança de subscrições digitais.

## Estado real da implementação

### Já existe na base v0.6.0
- Aplicação Expo / React Native / TypeScript.
- Integração Firebase Authentication e Cloud Firestore.
- Conversas e mensagens de texto em tempo real na implementação actual.
- Limite de até cinco administradores por grupo nas regras e serviço existentes.

### Ainda não está implementado/validado
- A política final de autenticação exclusivamente por telefone ainda não está reflectida no `App.tsx` actual (que contém e-mail e autenticação anónima).
- A lista telefónica e correspondência por número ainda não estão implementadas.
- A Bíblia ACF integral e FILES SALVOS ainda não estão implementados.
- LetsPay ainda não tem integração real com PayPal, m-Pesa, e-Mola, Pix ou Airtm.
- Não há backend de ledger, KYC, câmbio, pagamentos, PIN ou transferências.
- As regras Firestore deste pacote impedem escrita directa do cliente nas carteiras; isso é uma protecção inicial, não substitui o backend.

## Ficheiros acrescentados
- `LETSCHATAPP_LETSPAY_SPEC.md` — especificação funcional e técnica consolidada.
- `letsPay.ts` — tipos, limites, validação de PIN, fornecedores e cálculo de intervalo/valor local. São utilitários locais, não executam pagamentos.

## Próximas etapas obrigatórias
1. Corrigir autenticação e perfil para telefone apenas, mantendo SMS opcional na primeira versão.
2. Implementar permissões e selecção de contactos Android.
3. Criar Firebase Cloud Functions/backend e ledger transaccional.
4. Integrar fornecedores de pagamento país a país e obter aprovações.
5. Implementar KYC/AML, PIN seguro, câmbio e limites.
6. Só depois activar transacções reais e preparar o APK de produção.

**Aviso:** não introduzir dinheiro real nesta versão. Não colocar chaves secretas, credenciais de fornecedores ou `google-services.json` no repositório.
